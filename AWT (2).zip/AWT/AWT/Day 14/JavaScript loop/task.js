let j=0;
do{
  document.write("<br/>"+j);
  j++;
}
while (j < 10);
document.write("<hr/>");

const Human = {FirstName:"Abhishek", LastName:"Pujara", age:25};
for (let H in Human) {
    document.write("<br/>"+H);
  }
document.write("<hr/>");
for (let H in Human) {
  document.write("<br/>"+Human[H]);
}
document.write("<hr/>")
const cities = ["New York", "Tokiyo", "Delhi"];
for (C of cities) {
  document.write("<br/>"+C);
}
document.write("<hr/>")
for (let i = 0; i < 5; i++) {
    document.write("The number is " + i + "<br>");
}
document.write("<hr/>")
let i=0;
while (i < 10) {
    document.write("<br/>"+i);
    i++;
}

