        function demoExternalAlert(){
            alert("This is Vatsal Vaghasiya")
        }
        function demoExternalConfirm(){
            if(confirm("Welcome")){
                alert("Refer our program")
            }
            else{
                alert(" You need any help")
            }
        }
        function demoInternalconfirm(){
            if(confirm("Welcome")){
                alert("Refer our program")
            }
            else{
                alert("You need any help")
            }
        }
       